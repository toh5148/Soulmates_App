package appdev.toh5148.animaljam;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.support.annotation.NonNull;

/**
 * Created by toh5148 on 3/28/16.
 */

public class ProfileContentProvider extends ContentProvider {

    private JamDB theDB;

    private static final String AUTHORITY = "appdev.toh5148.animaljam.ProfileContentProvider";
    private static final String BASE_PATH = "animals";
    public static final Uri CONTENT_URI = Uri.parse("content://" + AUTHORITY + "/" +
            BASE_PATH);

    private static final UriMatcher uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
    private static final int ANIMALS = 1;
    private static final int ANIMALS_ID = 2;
    static {
        uriMatcher.addURI(AUTHORITY, BASE_PATH, ANIMALS);
        uriMatcher.addURI(AUTHORITY, BASE_PATH + "/#", ANIMALS_ID);
    }

    @Override
    public boolean onCreate() {
        theDB = JamDB.getInstance(getContext());
        return true;
    }

    @Override
    public Uri insert(@NonNull Uri uri, ContentValues values) {
        long id;
        SQLiteDatabase db = theDB.getWritableDatabase();

        switch (uriMatcher.match(uri)) {
            case ANIMALS:
                id = db.insert("animals", null, values);
                break;
            default:
                throw new IllegalArgumentException("Unknown URI: " + uri);
        }

        getContext().getContentResolver().notifyChange(uri, null);

        return Uri.parse(BASE_PATH + "/" + id);
    }


    @Override
    public Cursor query(@NonNull Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {

        SQLiteDatabase db = theDB.getReadableDatabase();
        Cursor cursor;

        switch (uriMatcher.match(uri)) {
            case ANIMALS:
                cursor = db.query("animals", projection, selection,
                        selectionArgs, null, null, sortOrder);
                break;
            case ANIMALS_ID:
                cursor = db.query("profiles", projection,
                        appendIdToSelection(selection, uri.getLastPathSegment()),
                        selectionArgs, null, null, sortOrder);
                break;
            default:
                throw new IllegalArgumentException("Unknown URI: " + uri);
        }

        cursor.setNotificationUri(getContext().getContentResolver(), uri);

        return cursor;
    }

    @Override
    public int update(@NonNull Uri uri, ContentValues values, String selection,
                      String[] selectionArgs) {
        int count;
        SQLiteDatabase db = theDB.getWritableDatabase();

        switch (uriMatcher.match(uri)){
            case ANIMALS:
                count = db.update("animals", values, selection, selectionArgs);
                break;
            case ANIMALS_ID:
                count = db.update("animals", values,
                        appendIdToSelection(selection, uri.getLastPathSegment()),
                        selectionArgs);
                break;
            default:
                throw new IllegalArgumentException("Unknown URI " + uri );
        }
        getContext().getContentResolver().notifyChange(uri, null);
        return count;
    }


    @Override
    public int delete(@NonNull Uri uri, String selection, String[] selectionArgs) {
        int count;
        SQLiteDatabase db = theDB.getWritableDatabase();

        switch (uriMatcher.match(uri)){
            case ANIMALS:
                count = db.delete("animals", selection, selectionArgs);
                break;
            case ANIMALS_ID:
                count = db.delete("animals",
                        appendIdToSelection(selection, uri.getLastPathSegment()),
                        selectionArgs);
                break;
            default:
                throw new IllegalArgumentException("Unknown URI " + uri);
        }

        getContext().getContentResolver().notifyChange(uri, null);
        return count;
    }

    @Override
    public String getType(@NonNull Uri uri) {
        return null;
    }

    private String appendIdToSelection(String selection, String sId) {
        int id = Integer.valueOf(sId);

        if (selection == null || selection.trim().equals(""))
            return "_ID = " + id;
        else
            return selection + " AND _ID = " + id;
    }
}