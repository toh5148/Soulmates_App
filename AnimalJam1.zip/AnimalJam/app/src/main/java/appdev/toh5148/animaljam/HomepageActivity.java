package appdev.toh5148.animaljam;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Toast;

public class HomepageActivity extends AppCompatActivity {

    private int userID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(getIntent().getExtras() != null) {
            userID = getIntent().getExtras().getInt("userID", -1);
        }
        else {
            userID = -1;
        }
        setContentView(R.layout.activity_homepage);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    public void searchClick(View view) {
        //Allow the user to search the database for some match on a name
        Intent intent = new Intent(this, SearchActivity.class);
        startActivity(intent);
    }

    public void favoritesClick(View view) {
        //Show the user a list view of their favorite profiles
        if(isSignedIn()) {

        }
        else {
            Toast.makeText(getApplicationContext(), "Sign in to view your favorite animals", Toast.LENGTH_LONG).show();
        }
    }

    public void addClick(View view) {
        //Allow the user to add a new animal profile to the db
        if(isSignedIn()) {
            Intent intent = new Intent(this, AddAnimalActivity.class);
            startActivity(intent);
        }
        else {
            Toast.makeText(getApplicationContext(), "Sign in to add an animal profile", Toast.LENGTH_LONG).show();
        }
    }

    private boolean isSignedIn() {
        return userID != -1;
    }

}
