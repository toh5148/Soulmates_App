package appdev.toh5148.animaljam;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AddAnimalActivity extends AppCompatActivity {
    String scientificName;
    String name;
    String description;
    String location;
    String image;
    public interface OnAddedReadyListener {
        public void onReady();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_animal);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    public void addAnimalClick(View view) {
        this.name = ((EditText) findViewById(R.id.name)).getText().toString();
        this.scientificName = ((EditText) findViewById(R.id.scientificName)).getText().toString();
        this.description = ((EditText) findViewById(R.id.description)).getText().toString();
        this.location = ((EditText) findViewById(R.id.location)).getText().toString();
        this.image = ((EditText) findViewById(R.id.imageID)).getText().toString();

        // Check to see that every field has information entered
        if (name.equals("") || scientificName.equals("") || description.equals("") || location.equals("") || image.equals("")){
            Toast.makeText(this, "Please enter information into each field.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Trying to add animal.", Toast.LENGTH_SHORT).show();

            new addAnimalAsyncTask().execute(new OnAddedReadyListener() {
                @Override
                public void onReady() {
                    Toast.makeText(AddAnimalActivity.this, "Animal has been added.", Toast.LENGTH_SHORT).show();
                    finish();
                }
            });


        }
    }

    public void getWritableDatabase(OnAddedReadyListener listener) {
        new addAnimalAsyncTask().execute(listener);
    }

    private String getScientificName(){
        return this.scientificName;
    }
    private String getName(){
        return this.name;
    }
    private String getDescription(){
        return this.description;
    }
    private String getLocation(){
        return this.location;
    }
    private String getImage(){
        return this.image;
    }

    private class addAnimalAsyncTask extends AsyncTask<OnAddedReadyListener, Void, OnAddedReadyListener> {
        @Override
        protected OnAddedReadyListener doInBackground(OnAddedReadyListener... params) {
            OnAddedReadyListener listener = params[0];
            addAnimalToDB();
            return listener;
        }

        @Override
        protected void onPostExecute(OnAddedReadyListener listener) {
            listener.onReady();
        }

        private void addAnimalToDB(){
            JamDB.getInstance(AddAnimalActivity.this).getWritableDatabase(new JamDB.OnDBReadyListener() {
                @Override
                public void onReady(SQLiteDatabase theDB) {
                    theDB.beginTransaction();

                    ContentValues values = new ContentValues();
                    values.put("name", getName());
                    values.put("description", getDescription());
                    values.put("location", getLocation());
                    values.put("imageID", Integer.parseInt(getImage()));
                    values.put("scientificName", getScientificName());

                    theDB.insert("animals", null, values);
                    theDB.setTransactionSuccessful();

                    theDB.endTransaction();
                }
            });
        }
    }
}
