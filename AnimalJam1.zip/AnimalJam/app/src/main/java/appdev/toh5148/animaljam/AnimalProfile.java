package appdev.toh5148.animaljam;


import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class AnimalProfile extends AppCompatActivity {

    SQLiteDatabase theDB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animal_profile);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        JamDB.getInstance(this).getWritableDatabase(new JamDB.OnDBReadyListener() {
            @Override
            public void onReady(SQLiteDatabase theDB) {
                AnimalProfile.this.theDB = theDB;
                loadAnimal(1);
            }
        });
    }

    private void loadAnimal(int animalID) {
        ImageView image = (ImageView) findViewById(R.id.profile_image);
        TextView name = (TextView) findViewById(R.id.animal_name);
        TextView sciName = (TextView) findViewById(R.id.scientificName);
        TextView location = (TextView) findViewById(R.id.location);
        TextView description = (TextView) findViewById(R.id.description);

        if(theDB == null) {
            Toast.makeText(this, "Try again in a few seconds.", Toast.LENGTH_SHORT).show();
        }
        else {
            String[] columns = {"_id", "name", "description", "location", "imageID", "scientificName"};
            String selection = "_id = '" + animalID + "'";
            Cursor c = theDB.query("animals", columns, selection, null, null, null, "_id");
            if(c.moveToNext()) {
                String dbName = c.getString(c.getColumnIndexOrThrow("name"));
                String dbSciName = c.getString(c.getColumnIndexOrThrow("scientificName"));
                String dbDescription = c.getString(c.getColumnIndexOrThrow("description"));
                String dbLocation = c.getString(c.getColumnIndexOrThrow("location"));
                int dbImageID = (int) c.getLong(c.getColumnIndexOrThrow("imageID"));

                name.setText(dbName);
                sciName.setText(dbSciName);
                location.setText(dbLocation);
                description.setText(dbDescription);
                setImage(dbImageID, image);
            }
        }
    }

    private void setImage(int imageID, ImageView image) {
        if(imageID == 1) {
            image.setImageResource(R.mipmap.dog);
        }
        else {
            image.setImageResource(R.mipmap.ic_launcher);
        }
    }

}
