package appdev.toh5148.animaljam;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class LogInActivity extends AppCompatActivity {

    SQLiteDatabase theDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        JamDB.getInstance(this).getWritableDatabase(new JamDB.OnDBReadyListener() {
            @Override
            public void onReady(SQLiteDatabase theDB) {
                LogInActivity.this.theDB = theDB;
            }
        });
    }

    public void signInClick(View view) {
        int passedAuthentication = authenticateUser();

        if(passedAuthentication != -1) {
            //Goto homepage, make extra with user id
            Intent intent = new Intent(this, HomepageActivity.class);
            intent.putExtra("userID", passedAuthentication);
            startActivity(intent);
        }
        else {
            Toast.makeText(getApplicationContext(), "Invalid Username and Password", Toast.LENGTH_LONG).show();
        }
    }

    public void registerClick(View view) {
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
    }

    public void skipSignInClick(View view) {
        //Go to Homepage
        Intent intent = new Intent(this, HomepageActivity.class);
        startActivity(intent);
    }

    private int authenticateUser() {
        int retVal = -1;
        String username = ((EditText) findViewById(R.id.username)).getText().toString();
        String password = ((EditText) findViewById(R.id.password)).getText().toString();

        if(theDB == null) {
            Toast.makeText(this, "Try again in a few seconds.", Toast.LENGTH_SHORT).show();
        }
        else {
            String[] columns = {"_id", "username", "password"};
            String selection = "username = '" + username + "'";
            Cursor c = theDB.query("users", columns, selection, null, null, null, "_id");
            if(c.moveToNext()) {
                String dbUsername = c.getString(c.getColumnIndexOrThrow("username"));
                String dbPassword = c.getString(c.getColumnIndexOrThrow("password"));

                if(username.equals(dbUsername) && password.equals(dbPassword)) {
                    retVal = (int)c.getLong(c.getColumnIndexOrThrow("_id"));
                }
            }
        }

        return retVal;
    }

}
