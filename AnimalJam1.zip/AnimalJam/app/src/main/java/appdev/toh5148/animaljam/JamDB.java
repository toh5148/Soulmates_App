package appdev.toh5148.animaljam;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.AsyncTask;

/**
 * Created by toh5148 on 4/25/16.
 */

public class JamDB extends SQLiteOpenHelper {
    public interface OnDBReadyListener {
        public void onReady(SQLiteDatabase theDB);
    }

    public static final int DATABASE_VERSION = 4;
    public static final String DATABASE_NAME = "jam.db";

    private static JamDB theDB;

    private JamDB(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public static synchronized JamDB getInstance(Context context) {
        if (theDB == null)
            theDB = new JamDB(context.getApplicationContext());

        return theDB;
    }

    private static final String USER_SQL_CREATE =
            "CREATE TABLE users (" +
                    "_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "username TEXT, " +
                    "password TEXT)";

    private static final String ANIMAL_SQL_CREATE =
            "CREATE TABLE animals (" +
                    "_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "name TEXT, " +
                    "description TEXT, " +
                    "location TEXT, " +
                    "imageID INTEGER, " +
                    "scientificName TEXT)";

    private static final String FAVORITES_SQL_CREATE =
            "CREATE TABLE favorites (" +
                    "_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "userID INTEGER, " +
                    "animalID INTEGER)";

    private static final String USER_DELETE_ENTRIES = "DROP TABLE IF EXISTS users";
    private static final String ANIMAL_DELETE_ENTRIES = "DROP TABLE IF EXISTS animals";
    private static final String FAVORITES_DELETE_ENTRIES = "DROP TABLE IF EXISTS favorites";

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(USER_SQL_CREATE);
        addUsers(db);
        db.execSQL(ANIMAL_SQL_CREATE);
        addAnimals(db);
        db.execSQL(FAVORITES_SQL_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(USER_DELETE_ENTRIES);
        db.execSQL(ANIMAL_DELETE_ENTRIES);
        db.execSQL(FAVORITES_DELETE_ENTRIES);
        onCreate(db);
    }

    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }

    public void getWritableDatabase(OnDBReadyListener listener) {
        new OpenDBAsyncTask().execute(listener);
    }

    private class OpenDBAsyncTask extends AsyncTask<OnDBReadyListener, Void, SQLiteDatabase> {
        OnDBReadyListener listener;

        @Override
        protected SQLiteDatabase doInBackground(OnDBReadyListener... params) {
            listener = params[0];
            return theDB.getWritableDatabase();
        }

        @Override
        protected void onPostExecute(SQLiteDatabase theDB) {
            listener.onReady(theDB);
        }
    }

    private void addUsers(SQLiteDatabase db) {
        db.beginTransaction();
        ContentValues values = new ContentValues();
        values.put("username", "admin");
        values.put("password", "admin");
        db.insert("users", null, values);
        db.setTransactionSuccessful();
        db.endTransaction();

        db.beginTransaction();
        values = new ContentValues();
        values.put("username", "Sawyer");
        values.put("password", "Brown");
        db.insert("users", null, values);
        db.setTransactionSuccessful();
        db.endTransaction();

        db.beginTransaction();
        values = new ContentValues();
        values.put("username", "Tom");
        values.put("password", "Hoffman");
        db.insert("users", null, values);
        db.setTransactionSuccessful();
        db.endTransaction();
    }

    private void addAnimals(SQLiteDatabase db) {
        db.beginTransaction();
        ContentValues values = new ContentValues();
        values.put("name", "Dog");
        values.put("description", "Dogs are often furry and come in many colors. They are usually referred to as 'Man's best friend', however some people are afraid of them due to traumatic events in the past.");
        values.put("scientificName", "Canis-lupus-familiaris");
        values.put("location", "North America");
        values.put("imageID", 1);
        db.insert("animals", null, values);
        db.setTransactionSuccessful();
        db.endTransaction();
    }

}
