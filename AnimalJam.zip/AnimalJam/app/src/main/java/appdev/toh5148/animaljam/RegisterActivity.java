package appdev.toh5148.animaljam;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    SQLiteDatabase theDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        JamDB.getInstance(this).getWritableDatabase(new JamDB.OnDBReadyListener() {
            @Override
            public void onReady(SQLiteDatabase theDB) {
                RegisterActivity.this.theDB = theDB;
            }
        });
    }

    public void createAccountClick(View view) {
        boolean successfullyCreated = createAccount();

        if(successfullyCreated) {
            finish();
        }
    }

    private boolean createAccount() {
        boolean retVal = false;
        String username = ((EditText) findViewById(R.id.username)).getText().toString();
        String password = ((EditText) findViewById(R.id.password)).getText().toString();
        String rPassword = ((EditText) findViewById(R.id.reenter_password)).getText().toString();

        if(!username.equals("") && !password.equals("") && password.equals(rPassword)) {
            addUser(username, password);
            Toast.makeText(getApplicationContext(), "Account Created!", Toast.LENGTH_SHORT).show();
            retVal = true;
        }
        else {
            if(username.equals("")) {
                Toast.makeText(getApplicationContext(), "Username cannot be empty", Toast.LENGTH_SHORT).show();
            }
            else if (password.equals("")) {
                Toast.makeText(getApplicationContext(), "Password cannot be empty", Toast.LENGTH_SHORT).show();
            }
            else if(!password.equals(rPassword)) {
                Toast.makeText(getApplicationContext(), "Passwords do not match", Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(getApplicationContext(), "Error creating account", Toast.LENGTH_SHORT).show();
            }
        }
        return retVal;
    }

    public void addUser(String user, String password) {
        theDB.beginTransaction();
        ContentValues values = new ContentValues();
        values.put("username", user);
        values.put("password", password);
        theDB.insert("users", null, values);
        theDB.setTransactionSuccessful();
        theDB.endTransaction();
    }
}
