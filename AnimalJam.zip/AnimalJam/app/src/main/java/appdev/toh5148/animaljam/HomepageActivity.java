package appdev.toh5148.animaljam;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class HomepageActivity extends AppCompatActivity {

    private int userID;
    SQLiteDatabase theDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(getIntent().getExtras() != null) {
            userID = getIntent().getExtras().getInt("userID", -1);
        }
        else {
            userID = -1;
        }
        setContentView(R.layout.activity_homepage);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        JamDB.getInstance(this).getWritableDatabase(new JamDB.OnDBReadyListener() {
            @Override
            public void onReady(SQLiteDatabase theDB) {
                HomepageActivity.this.theDB = theDB;
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_log_in, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void searchClick(View view) {
        if(getSharedPreference()) {
            Toast.makeText(getApplicationContext(), "Get back to work you fool", Toast.LENGTH_LONG).show();
            return;
        }
        //Allow the user to search the database for some match on a name
        Intent intent = new Intent(this, SearchActivity.class);
        intent.putExtra("userID", userID);
        startActivity(intent);
    }

    public void favoritesClick(View view) {
        if(getSharedPreference()) {
            Toast.makeText(getApplicationContext(), "Get back to work you fool", Toast.LENGTH_LONG).show();
            return;
        }
        //Show the user a list view of their favorite profiles
        if(isSignedIn()) {
            int animalID = getRandomFavorite();
            if(animalID != -1) {
                Intent intent = new Intent(this, AnimalProfile.class);
                intent.putExtra("animalID", animalID);
                intent.putExtra("userID", userID);
                startActivity(intent);
            }
        }
        else {
            Toast.makeText(getApplicationContext(), "Sign in to view your favorite animals", Toast.LENGTH_LONG).show();
        }
    }

    public void addClick(View view) {
        if(getSharedPreference()) {
            Toast.makeText(getApplicationContext(), "Get back to work you fool", Toast.LENGTH_LONG).show();
            return;
        }
        //Allow the user to add a new animal profile to the db
        if(isSignedIn()) {
            Intent intent = new Intent(this, AddAnimalActivity.class);
            startActivity(intent);
        }
        else {
            Toast.makeText(getApplicationContext(), "Sign in to add an animal profile", Toast.LENGTH_LONG).show();
        }
    }

    private int getRandomFavorite() {
        if(theDB == null) {
            Toast.makeText(this, "Try again in a few seconds", Toast.LENGTH_SHORT).show();
            return -1;
        }
        else {
            String[] columns = {"_id", "userID", "animalID"};
            String selection = "userID = '" + userID + "'";
            Cursor c = theDB.query("favorites", columns, selection, null, null, null, "_id");
            if(!c.moveToNext()) {
                Toast.makeText(this, "Try adding some favorites and try again", Toast.LENGTH_SHORT).show();
                return -1;
            }
            int counter = 1;
            while(c.moveToNext()) {
                counter++;
            }
            //Counter holds number of favorites;

            c = theDB.query("favorites", columns, selection, null, null, null, "_id");

            int retVal = -1;
            int number = (int)(Math.random() * 100) % counter;
            while(c.moveToNext() && number >= 0) {
                int temp = (int)c.getLong(c.getColumnIndexOrThrow("animalID"));
                retVal = temp;
                number--;
            }

            return retVal;

        }
    }

    private boolean getSharedPreference() {
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);
        return sharedPref.getBoolean("workmode", false);
    }

    private boolean isSignedIn() {
        return userID != -1;
    }

}
