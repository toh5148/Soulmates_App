package appdev.toh5148.animaljam;

import android.app.LoaderManager;
import android.content.CursorLoader;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class SearchActivity extends AppCompatActivity {

    SQLiteDatabase theDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        JamDB.getInstance(this).getWritableDatabase(new JamDB.OnDBReadyListener() {
            @Override
            public void onReady(SQLiteDatabase theDB) {
                SearchActivity.this.theDB = theDB;
            }
        });
    }

    public void searchForAnimal(View view) {
        String animalName = ((EditText) findViewById(R.id.animal_search)).getText().toString();

        if(theDB == null) {
            Toast.makeText(this, "Try again in a few seconds.", Toast.LENGTH_SHORT).show();
        }
        else {
            String[] columns = {"_id", "name"};
            String selection = "name = '" + animalName + "'";
            Cursor c = theDB.query("animals", columns, selection, null, null, null, "_id");

            if(c.moveToNext()) {
                int animalID = (int)c.getLong(c.getColumnIndexOrThrow("_id"));
                redirectToProfile(animalID);
            }
            else {
                //No animal found
                displayNoResults(animalName);
            }
        }
    }

    public void redirectToProfile(int id) {
        Intent intent = new Intent(this, AnimalProfile.class);
        intent.putExtra("animalID", id);
        startActivity(intent);
    }

    public void displayNoResults(String animalName) {
        TextView noResults = (TextView) findViewById(R.id.txt_NoResults);
        noResults.setText("Sorry, there were no results found for '" + animalName + "'");
    }

}
