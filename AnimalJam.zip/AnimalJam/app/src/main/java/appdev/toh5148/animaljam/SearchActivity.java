package appdev.toh5148.animaljam;

import android.app.LoaderManager;
import android.content.CursorLoader;
import android.content.Intent;
import android.content.Loader;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class SearchActivity extends AppCompatActivity {

    SQLiteDatabase theDB;
    int userID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if(getIntent().getExtras() != null) {
            userID = getIntent().getExtras().getInt("userID", -1);
        }
        else {
            userID = -1;
        }

        JamDB.getInstance(this).getWritableDatabase(new JamDB.OnDBReadyListener() {
            @Override
            public void onReady(SQLiteDatabase theDB) {
                SearchActivity.this.theDB = theDB;
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_log_in, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void searchForAnimal(View view) {
        String animalName = ((EditText) findViewById(R.id.animal_search)).getText().toString();

        if(theDB == null) {
            Toast.makeText(this, "Try again in a few seconds.", Toast.LENGTH_SHORT).show();
        }
        else {
            String[] columns = {"_id", "name"};
            String selection = "name = '" + animalName + "'";
            Cursor c = theDB.query("animals", columns, selection, null, null, null, "_id");

            if(c.moveToNext()) {
                int animalID = (int)c.getLong(c.getColumnIndexOrThrow("_id"));
                redirectToProfile(animalID);
            }
            else {
                //No animal found
                displayNoResults(animalName);
            }
        }
    }

    public void redirectToProfile(int id) {
        Intent intent = new Intent(this, AnimalProfile.class);
        intent.putExtra("animalID", id);
        intent.putExtra("userID", userID);
        startActivity(intent);
    }

    public void displayNoResults(String animalName) {
        TextView noResults = (TextView) findViewById(R.id.txt_NoResults);
        noResults.setText("Sorry, there were no results found for '" + animalName + "'");
    }

}
