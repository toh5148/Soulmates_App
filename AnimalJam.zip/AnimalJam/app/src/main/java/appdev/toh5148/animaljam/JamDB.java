package appdev.toh5148.animaljam;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.AsyncTask;

/**
 * Created by toh5148 on 4/25/16.
 */

public class JamDB extends SQLiteOpenHelper {
    public interface OnDBReadyListener {
        public void onReady(SQLiteDatabase theDB);
    }

    public static final int DATABASE_VERSION = 7;
    public static final String DATABASE_NAME = "jam.db";

    private static JamDB theDB;

    private JamDB(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public static synchronized JamDB getInstance(Context context) {
        if (theDB == null)
            theDB = new JamDB(context.getApplicationContext());

        return theDB;
    }

    private static final String USER_SQL_CREATE =
            "CREATE TABLE users (" +
                    "_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "username TEXT, " +
                    "password TEXT)";

    private static final String ANIMAL_SQL_CREATE =
            "CREATE TABLE animals (" +
                    "_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "name TEXT, " +
                    "description TEXT, " +
                    "location TEXT, " +
                    "imageID INTEGER, " +
                    "scientificName TEXT)";

    private static final String FAVORITES_SQL_CREATE =
            "CREATE TABLE favorites (" +
                    "_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "userID INTEGER, " +
                    "animalID INTEGER)";

    private static final String USER_DELETE_ENTRIES = "DROP TABLE IF EXISTS users";
    private static final String ANIMAL_DELETE_ENTRIES = "DROP TABLE IF EXISTS animals";
    private static final String FAVORITES_DELETE_ENTRIES = "DROP TABLE IF EXISTS favorites";

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(USER_SQL_CREATE);
        addUsers(db);
        db.execSQL(ANIMAL_SQL_CREATE);
        addAnimals(db);
        db.execSQL(FAVORITES_SQL_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(USER_DELETE_ENTRIES);
        db.execSQL(ANIMAL_DELETE_ENTRIES);
        db.execSQL(FAVORITES_DELETE_ENTRIES);
        onCreate(db);
    }

    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }

    public void getWritableDatabase(OnDBReadyListener listener) {
        new OpenDBAsyncTask().execute(listener);
    }

    private class OpenDBAsyncTask extends AsyncTask<OnDBReadyListener, Void, SQLiteDatabase> {
        OnDBReadyListener listener;

        @Override
        protected SQLiteDatabase doInBackground(OnDBReadyListener... params) {
            listener = params[0];
            return theDB.getWritableDatabase();
        }

        @Override
        protected void onPostExecute(SQLiteDatabase theDB) {
            listener.onReady(theDB);
        }
    }

    private void addUsers(SQLiteDatabase db) {
        db.beginTransaction();
        ContentValues values = new ContentValues();
        values.put("username", "admin");
        values.put("password", "admin");
        db.insert("users", null, values);
        db.setTransactionSuccessful();
        db.endTransaction();

        db.beginTransaction();
        values = new ContentValues();
        values.put("username", "Sawyer");
        values.put("password", "Brown");
        db.insert("users", null, values);
        db.setTransactionSuccessful();
        db.endTransaction();

        db.beginTransaction();
        values = new ContentValues();
        values.put("username", "Tom");
        values.put("password", "Hoffman");
        db.insert("users", null, values);
        db.setTransactionSuccessful();
        db.endTransaction();
    }

    private void addAnimals(SQLiteDatabase db) {
        //Dog
        addAnimal(db, "Dog", "Canis-lupus-familiaris", "North America", 1, "The domestic dog is a domesticated canid which has been selectively bred for millennia for various behaviors, sensory capabilities, and physical attributes.");
        addAnimal(db, "Cat", "Felis-catus", "Egypt", 2, "Cats have been domesticated (tame) for nearly 10,000 years. They are currently the most popular pets in the world. Their origin is probably the African Wildcat Felis silvestris lybica.Cats were probably first kept because they ate mice, and this is still their main 'job' in farms throughout the world. Later they were kept because they are friendly and good companions.");
        addAnimal(db, "Mouse", "Mus", "Southeast Asia", 3, "A mouse is a small rodent characteristically having a pointed snout, small rounded ears, a body-length scaly tail and a high breeding rate. The best known mouse species is the common house mouse. It is also a popular pet.");
        addAnimal(db, "Lion", "Panthera-leo", "Southern Africa", 4, "The lion is one of the big cats in the genus Panthera and a member of the family Felidae. The commonly used term African lion collectively denotes the several subspecies found in Africa.");
        addAnimal(db, "Tiger", "Panthera-tigris", "Africa", 5, "The tiger is the largest cat species, most recognisable for their pattern of dark vertical stripes on reddish-orange fur with a lighter underside");
        addAnimal(db, "Bird", "Aves", "China, South America", 6, "Birds are a group of endothermic vertebrates, characterised by feathers, toothless beaked jaws, the laying of hard-shelled eggs, a high metabolic rate, a four-chambered heart, and a lightweight but strong skeleton.");
        addAnimal(db, "T-Rex", "Tyrannosaurus", "Western United States", 7, "“Tyrannosaurus” is Greek for “tyrant lizard,” and “rex” means “king” in Latin. So, Tyrannosaurus rex was “King of the Tyrant Lizards.” T. rex lived about 66–68 million years ago during the Cretaceous Period in the western United States, including Montana and Wyoming.");
        addAnimal(db, "Dr. Blum", "Canis-lupus-familiaris", "W-255", 8, "Dr. Blum is commonly found on the Penn State Harrisburg campus. In his free time that is not spent terrorizing young freshmen, he enjoys writing the letter 'F' on random pieces of paper (also known as tests).");

    }

    private void addAnimal(SQLiteDatabase db, String n, String sN, String l, int id, String d) {
        db.beginTransaction();
        ContentValues values = new ContentValues();
        values.put("name", n);
        values.put("description", d);
        values.put("scientificName", sN);
        values.put("location", l);
        values.put("imageID", id);
        db.insert("animals", null, values);
        db.setTransactionSuccessful();
        db.endTransaction();
    }

}
